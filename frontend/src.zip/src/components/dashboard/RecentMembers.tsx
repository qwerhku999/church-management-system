import { ArrowRight } from "lucide-react";

interface RecentMembersProps {
  dashboard?: {
    recent?: {
      members?: Array<{ firstName?: string; lastName?: string; createdAt?: string }>;
    };
  };
}

export default function RecentMembers({ dashboard }: RecentMembersProps) {
  const members = dashboard?.recent?.members ?? [];

  return (
    <>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Recent Members</h2>
          <p className="text-sm text-[var(--muted)]">Newly registered members</p>
        </div>

        <button className="flex items-center gap-2 text-sm font-medium text-blue-500 transition hover:text-blue-400">
          View All
          <ArrowRight size={16} />
        </button>
      </div>

      <div className="space-y-4">
        {members.length === 0 ? (
          <p className="text-sm text-[var(--muted)]">No recent members available yet.</p>
        ) : (
          members.slice(0, 4).map((member, index) => {
            const name = `${member.firstName ?? "Member"} ${member.lastName ?? ""}`.trim();
            return (
              <div key={`${name}-${index}`} className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-[var(--surface-2)] p-4 transition hover:border-blue-500/40 hover:bg-[var(--surface-hover)]">
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-500 text-lg font-bold text-white">
                    {name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-semibold">{name}</h3>
                    <p className="text-sm text-[var(--muted)]">Joined {member.createdAt ? new Date(member.createdAt).toLocaleDateString() : "recently"}</p>
                  </div>
                </div>
                <span className="text-sm text-[var(--muted)]">New</span>
              </div>
            );
          })
        )}
      </div>
    </>
  );
}