import AttendanceChart from "./AttendanceChart";
import DonationChart from "./DonationChart";
import RecentMembers from "./RecentMembers";

export default function DashboardGrid() {
  return (
    <section className="space-y-6">
      {/* Top Row */}

      <div className="grid gap-6 xl:grid-cols-3">
        {/* Attendance */}

        <div className="xl:col-span-2 rounded-3xl border border-white/5 bg-[var(--surface)] p-6 shadow-xl">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">
                Attendance Overview
              </h2>

              <p className="mt-1 text-sm text-[var(--muted)]">
                Weekly church attendance
              </p>
            </div>

            <button className="rounded-xl bg-[var(--primary)] px-4 py-2 text-sm font-medium text-white">
              Weekly
            </button>
          </div>

          <AttendanceChart />
        </div>

        {/* Donations */}

        <div className="rounded-3xl border border-white/5 bg-[var(--surface)] p-6 shadow-xl">
          <div className="mb-6">
            <h2 className="text-2xl font-bold">
              Donations
            </h2>

            <p className="mt-1 text-sm text-[var(--muted)]">
              Monthly giving
            </p>
          </div>

          <DonationChart />
        </div>
      </div>

      {/* Bottom */}

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Members */}

        <div className="lg:col-span-2 rounded-3xl border border-white/5 bg-[var(--surface)] p-6 shadow-xl">
          <RecentMembers />
        </div>

        {/* Events */}

        <div className="rounded-3xl border border-white/5 bg-[var(--surface)] p-6 shadow-xl">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">
              Upcoming Events
            </h2>

            <button className="text-sm text-[var(--primary)]">
              View All
            </button>
          </div>

          <div className="mt-6 space-y-4">
            <div className="rounded-2xl bg-white/5 p-4">
              <h3 className="font-semibold">
                Sunday Worship
              </h3>

              <p className="mt-1 text-sm text-[var(--muted)]">
                Sunday • 8:00 AM
              </p>
            </div>

            <div className="rounded-2xl bg-white/5 p-4">
              <h3 className="font-semibold">
                Youth Meeting
              </h3>

              <p className="mt-1 text-sm text-[var(--muted)]">
                Friday • 6:00 PM
              </p>
            </div>

            <div className="rounded-2xl bg-white/5 p-4">
              <h3 className="font-semibold">
                Choir Rehearsal
              </h3>

              <p className="mt-1 text-sm text-[var(--muted)]">
                Saturday • 4:00 PM
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}