import { LucideIcon, TrendingUp } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  change?: string;
}

export default function StatCard({
  title,
  value,
  icon: Icon,
  change,
}: StatCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-3xl border border-white/5 bg-[var(--surface)] p-6 transition-all duration-300 hover:-translate-y-1 hover:border-[var(--primary)]/30 hover:shadow-2xl">

      {/* Glow */}

      <div className="absolute right-0 top-0 h-24 w-24 translate-x-8 -translate-y-8 rounded-full bg-[var(--primary)]/10 blur-3xl transition group-hover:bg-[var(--primary)]/20" />

      <div className="relative flex items-start justify-between">

        <div>

          <p className="text-sm font-medium text-[var(--muted)]">
            {title}
          </p>

          <h2 className="mt-3 text-4xl font-bold tracking-tight">
            {value}
          </h2>

          {change && (
            <div className="mt-5 inline-flex items-center gap-2 rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-400">
              <TrendingUp size={14} />
              {change}
            </div>
          )}

        </div>

        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[var(--primary)]/10 text-[var(--primary)] transition duration-300 group-hover:bg-[var(--primary)] group-hover:text-white">
          <Icon size={30} />
        </div>

      </div>
    </div>
  );
}