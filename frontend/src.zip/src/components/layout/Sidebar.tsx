"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  UserCheck,
  CalendarDays,
  Building2,
  Wallet,
  HeartHandshake,
  FileText,
  Bell,
  BarChart3,
  Settings,
} from "lucide-react";

const menu = [
  { title: "Dashboard", href: "/", icon: LayoutDashboard },
  { title: "Members", href: "/members", icon: Users },
  { title: "Attendance", href: "/attendance", icon: UserCheck },
  { title: "Events", href: "/events", icon: CalendarDays },
  { title: "Ministries", href: "/ministries", icon: Building2 },
  { title: "Finance", href: "/finance", icon: Wallet },
  { title: "Prayer Requests", href: "/prayers", icon: HeartHandshake },
  { title: "Documents", href: "/documents", icon: FileText },
  { title: "Notifications", href: "/notifications", icon: Bell },
  { title: "Reports", href: "/reports", icon: BarChart3 },
  { title: "Settings", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="flex h-screen w-72 flex-col border-r border-white/5 bg-[#0b1220]">

      {/* Logo */}

      <div className="border-b border-white/5 px-7 py-8">
        <h1 className="text-2xl font-bold tracking-tight text-white">
          MinistryFlow
        </h1>

        <p className="mt-1 text-sm text-slate-400">
          Church Management
        </p>
      </div>

      {/* Navigation */}

      <nav className="flex-1 overflow-y-auto px-4 py-6">
        <div className="space-y-2">
          {menu.map((item) => {
            const Icon = item.icon;

            const active =
              pathname === item.href ||
              (item.href !== "/" &&
                pathname.startsWith(item.href));

            return (
              <Link
                key={item.title}
                href={item.href}
                className={`group flex items-center gap-4 rounded-2xl px-4 py-3 transition-all duration-200 ${
                  active
                    ? "bg-[var(--primary)] text-white shadow-lg"
                    : "text-slate-400 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Icon size={20} />

                <span className="font-medium">
                  {item.title}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Footer */}

      <div className="border-t border-white/5 p-5">

        <div className="rounded-2xl bg-white/5 p-4">
          <p className="font-semibold text-white">
            Administrator
          </p>

          <p className="mt-1 text-sm text-slate-400">
            Super Admin
          </p>
        </div>

        <div className="mt-6 text-center text-xs leading-6 text-slate-500">
          <p className="font-semibold text-slate-300">
            MinistryFlow v1.0.0
          </p>

          <p>© 2026 N.K. AMMONOH</p>

          <p>All Rights Reserved</p>
        </div>

      </div>

    </aside>
  );
}