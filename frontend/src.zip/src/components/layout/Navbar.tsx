"use client";

import {
  Bell,
  Search,
  Settings,
  ChevronDown,
} from "lucide-react";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-30 border-b border-[var(--border)] bg-[var(--bg)]/80 backdrop-blur-xl">
      <div className="flex h-20 items-center justify-between px-8">

        {/* Left */}

        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Dashboard
          </h1>

          <p className="mt-1 text-sm text-[var(--muted)]">
            Welcome back. Here&apos;s what&apos;s happening today.
          </p>
        </div>

        {/* Right */}

        <div className="flex items-center gap-4">

          {/* Search */}

          <div className="relative hidden lg:block">
            <Search
              size={18}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--muted)]"
            />

            <input
              placeholder="Search members, events..."
              className="h-12 w-80 rounded-xl border border-[var(--border)] bg-[var(--surface)] pl-11 pr-4 outline-none transition focus:border-[var(--primary)]"
            />
          </div>

          {/* Notification */}

          <button className="flex h-12 w-12 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] transition hover:bg-[var(--surface-hover)]">
            <Bell size={19} />
          </button>

          {/* Settings */}

          <button className="flex h-12 w-12 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] transition hover:bg-[var(--surface-hover)]">
            <Settings size={19} />
          </button>

          {/* User */}

          <button className="flex items-center gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-3 py-2 transition hover:bg-[var(--surface-hover)]">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[var(--primary)] font-semibold text-white">
              A
            </div>

            <div className="hidden text-left xl:block">
              <h3 className="text-sm font-semibold">
                Administrator
              </h3>

              <p className="text-xs text-[var(--muted)]">
                Super Admin
              </p>
            </div>

            <ChevronDown
              size={16}
              className="hidden text-[var(--muted)] xl:block"
            />
          </button>

        </div>

      </div>
    </header>
  );
}