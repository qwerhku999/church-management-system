import AppLayout from "@/components/layout/AppLayout";
import DashboardGrid from "@/components/dashboard/DashboardGrid";
import StatCard from "@/components/dashboard/StatCard";

import {
  Users,
  Wallet,
  CalendarDays,
  Church,
} from "lucide-react";

export default function HomePage() {
  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-8">

        {/* Stats First */}

        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          <StatCard
            title="Members"
            value="1,284"
            change="+18 this month"
            icon={Users}
          />

          <StatCard
            title="Donations"
            value="GHS 32,450"
            change="+12%"
            icon={Wallet}
          />

          <StatCard
            title="Events"
            value="12"
            change="This Week"
            icon={CalendarDays}
          />

          <StatCard
            title="Ministries"
            value="15"
            change="Active"
            icon={Church}
          />
        </div>

        {/* Dashboard */}

        <DashboardGrid />

      </div>
    </AppLayout>
  );
}